import { createClient } from '@supabase/supabase-js';
// Anon key aman di frontend selama RLS aktif. Jangan pernah pakai service role key di sini.
export const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);
