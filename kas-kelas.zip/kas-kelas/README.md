# Kas kelas

React + Vite + Supabase. Pengunjung hanya melihat; bendahara mencatat pembayaran dan pengeluaran.

## Langkah awal
1. Buat proyek di supabase.com.
2. Buka SQL Editor, tempel dan jalankan `supabase/schema.sql`.
3. Authentication > Providers > Email: matikan pendaftaran publik (Allow new users to sign up).
4. Authentication > Users: tambah satu pengguna (email + kata sandi) untuk bendahara.
5. Jadikan bendahara dengan SQL di bagian akhir `schema.sql` (ganti UUID).
6. Salin `.env.example` menjadi `.env`, isi URL dan anon key (Project Settings > API).
7. `npm install`, lalu `npm run dev`.

## Deploy
Vercel atau Netlify: hubungkan repo, isi dua variabel `VITE_...` di pengaturan proyek, build `npm run build`, output `dist`.

## Ide berikutnya
Ekspor PDF, kompres foto nota sebelum unggah, grafik bulanan, sinkron Google Sheets lewat Edge Function.
