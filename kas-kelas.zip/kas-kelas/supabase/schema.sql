-- Kas kelas: jalankan seluruh isi file ini di Supabase > SQL Editor.

create table public.profiles (
  id uuid primary key references auth.users on delete cascade,
  role text not null default 'viewer' check (role in ('treasurer','viewer'))
);
create table public.members (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  active boolean not null default true
);
create table public.periods (
  id uuid primary key default gen_random_uuid(),
  label text not null,
  amount integer not null check (amount > 0),
  due_date date not null default current_date
);
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  member_id uuid not null references public.members on delete cascade,
  period_id uuid not null references public.periods on delete cascade,
  amount_paid integer not null check (amount_paid >= 0),
  paid_at date not null default current_date,
  unique (member_id, period_id)
);
create table public.expenses (
  id uuid primary key default gen_random_uuid(),
  spent_on date not null default current_date,
  description text not null,
  amount integer not null check (amount > 0),
  receipt_path text
);

-- Akun baru otomatis menjadi pengunjung (viewer).
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id) values (new.id);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Cek peran di database, bukan di frontend.
create function public.is_treasurer() returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'treasurer')
$$;

-- profiles: pengguna hanya bisa membaca barisnya sendiri; tidak ada policy ubah,
-- jadi peran tidak bisa diubah dari aplikasi.
alter table public.profiles enable row level security;
create policy profiles_self_read on public.profiles for select to authenticated
  using (id = auth.uid());

-- Data kas: semua orang boleh melihat, hanya bendahara yang boleh menulis.
-- Ingin data hanya terlihat setelah login? Ganti "anon, authenticated" menjadi "authenticated".
do $$
declare t text;
begin
  foreach t in array array['members','periods','payments','expenses'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('create policy "%1$s_read" on public.%1$I for select to anon, authenticated using (true)', t);
    execute format('create policy "%1$s_write" on public.%1$I for all to authenticated using (public.is_treasurer()) with check (public.is_treasurer())', t);
  end loop;
end $$;

-- Bucket nota (privat, diakses lewat signed URL).
insert into storage.buckets (id, name, public) values ('receipts', 'receipts', false)
  on conflict (id) do nothing;
create policy receipts_read on storage.objects for select to anon, authenticated
  using (bucket_id = 'receipts');
create policy receipts_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'receipts' and public.is_treasurer());
create policy receipts_delete on storage.objects for delete to authenticated
  using (bucket_id = 'receipts' and public.is_treasurer());

-- Setelah membuat akun bendahara di Authentication > Users, jadikan bendahara:
-- update public.profiles set role = 'treasurer' where id = '<UUID-AKUN-BENDAHARA>';
